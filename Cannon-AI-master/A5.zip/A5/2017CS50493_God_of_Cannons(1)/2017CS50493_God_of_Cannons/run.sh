#!/bin/sh
a.exe
