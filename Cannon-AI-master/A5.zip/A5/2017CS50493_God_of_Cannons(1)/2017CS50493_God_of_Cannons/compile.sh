#!/bin/sh
g++ -O3 -std=c++11 abPrune1.cpp 
