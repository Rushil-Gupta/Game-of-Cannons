#!/bin/sh
a.out