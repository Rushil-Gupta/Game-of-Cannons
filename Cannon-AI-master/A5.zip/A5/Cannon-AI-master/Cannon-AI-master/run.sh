#!/bin/sh
./player