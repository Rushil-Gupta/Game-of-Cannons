#!/bin/sh
./learn.out